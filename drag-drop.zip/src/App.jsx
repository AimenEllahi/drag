import Scene from "./components/Scene";
import "./App.css";

function App() {
  return <Scene />;
}

export default App;
